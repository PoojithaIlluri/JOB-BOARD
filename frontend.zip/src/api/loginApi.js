import { authtoken } from "./_constants";

export const loginApi = async (user) => {
  const response = await fetch(`http://localhost/auth/login`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(user),
  });
  const jsonData = await response.json();
  return jsonData;
};

export const registerApi = async (user) => {
  const response = await fetch(`http://localhost/auth/register`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(user),
  });
  const jsonData = await response.json();
  return jsonData;
};

export const getUserApi = async () => {
  const response = await fetch(`http://localhost/auth/`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      authtoken,
    },
  });
  const jsonData = await response.json();
  return jsonData;
};

export const updateUserApi = async (data) => {
  const response = await fetch(`http://localhost/auth/`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      authtoken,
    },
    body: JSON.stringify(data),
  });
  const jsonData = await response.json();
  return jsonData;
};

export const deleteUserApi = async () => {
  const response = await fetch(`http://localhost/auth/`, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
      authtoken,
    },
  });
  const jsonData = await response.json();
  return jsonData;
};
