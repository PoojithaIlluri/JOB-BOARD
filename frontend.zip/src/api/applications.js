import { authtoken } from "./_constants";

export const applyJobApi = async (id) => {
  const response = await fetch(`http://localhost/applications/${id}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      authtoken
    },
  });
  const jsonData = await response.json();
  return jsonData;
};

export const getAllApplicationsApi = async (id) => {
  const response = await fetch(`http://localhost/applications`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      authtoken
    },
  });
  const jsonData = await response.json();
  return jsonData;
};
