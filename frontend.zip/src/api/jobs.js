import { authtoken } from "./_constants";

export const getAllJobsApi = async () => {
  const response = await fetch(`http://localhost/jobs`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
    },
  });
  const jsonData = await response.json();
  return jsonData;
};

export const getSingleJobApi = async (id) => {
  const response = await fetch(`http://localhost/jobs/${id}`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
    },
  });
  const jsonData = await response.json();
  return jsonData;
};

export const postJobApi = async (data) => {
  const response = await fetch(`http://localhost/jobs`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      authtoken,
    },
    body: JSON.stringify(data),
  });
  const jsonData = await response.json();
  return jsonData;
};
