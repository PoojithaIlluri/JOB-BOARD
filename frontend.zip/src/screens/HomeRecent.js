import React from "react";
import JobCard from "../components/JobCard";
import { Typography } from "@mui/material";

const HomeRecent = ({ jobs }) => {
  return (
    <div className="homeRecent">
      <Typography variant="h6" sx={{ color: "darkcyan" }}>
        Recent Job Applications
      </Typography>
      {jobs.length > 0 &&
        jobs
          .filter((_, index) => index < 5)
          .toReversed()
          .map((job) => <JobCard key={job._id} job={job} recent />)}
    </div>
  );
};

export default HomeRecent;
