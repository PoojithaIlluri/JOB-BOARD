import React, { useEffect, useState } from "react";
import {
  MDBCol,
  MDBContainer,
  MDBRow,
  MDBCard,
  MDBCardText,
  MDBCardBody,
  MDBCardImage,
} from "mdb-react-ui-kit";
import { Button } from "@mui/material";
import { Link, useNavigate } from "react-router-dom";
import { deleteUserApi, getUserApi } from "../api/loginApi";
import EditDialog from "../components/EditUser";

export default function ProfilePage() {
  const [user, setUser] = useState({});

  const fetchUser = async () => {
    const response = await getUserApi();
    if (response.message === "failed") {
      alert(response.errorMsg);
    } else {
      setUser(response.user);
    }
  };

  useEffect(() => {
    fetchUser();
  }, []);

  const navigate = useNavigate();
  if (localStorage.getItem("token") === null) {
    navigate("/login");
  }

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  const handleDelete = async () => {
    const response = await deleteUserApi();
    if (response.message === "failed") {
      alert(response.errorMsg);
    } else {
      alert("Successfully your account has been deleted!");
    }
    localStorage.removeItem("token");
    navigate("/login");
  };

  return (
    <section style={{ backgroundColor: "#eee" }}>
      <MDBContainer className="py-5">
        <div className="d-flex justify-content-end mb-3">
          <Link to={"/my-jobs"}>
            <Button sx={{ m: 1 }} variant="contained">
              My Jobs
            </Button>
          </Link>
          <div className="border-line"/>
          <EditDialog user={user} />
          <Button
            variant="contained"
            color="error"
            sx={{ m: 1 }}
            onClick={() => handleDelete()}
          >
            Delete
          </Button>
        </div>

        <MDBRow>
          <MDBCol lg="4">
            <MDBCard className="mb-4">
              <MDBCardBody className="text-center">
                <MDBCardImage
                  src={require("../assets/images/dummy.png")}
                  alt="avatar"
                  className="rounded-circle"
                  style={{
                    width: "200px",
                    height: "200px",
                    objectFit: "cover",
                  }}
                  fluid
                />
                <p className="text-muted my-1">{user && user.description}</p>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol lg="8">
            <MDBCard className="mb-4">
              <MDBCardBody>
                <MDBRow>
                  <MDBCol sm="3">
                    <MDBCardText>Full Name</MDBCardText>
                  </MDBCol>
                  <MDBCol sm="9">
                    <MDBCardText className="text-muted">
                      {user && user.fullname}
                    </MDBCardText>
                  </MDBCol>
                </MDBRow>
                <hr />
                <MDBRow>
                  <MDBCol sm="3">
                    <MDBCardText>Email</MDBCardText>
                  </MDBCol>
                  <MDBCol sm="9">
                    <MDBCardText className="text-muted">
                      {user && user.email}
                    </MDBCardText>
                  </MDBCol>
                </MDBRow>
                <hr />
                <MDBRow>
                  <MDBCol sm="3">
                    <MDBCardText>Role</MDBCardText>
                  </MDBCol>
                  <MDBCol sm="9">
                    <MDBCardText className="text-muted">
                      {user && user.role}
                    </MDBCardText>
                  </MDBCol>
                </MDBRow>
                <hr />
                <MDBRow>
                  <MDBCol sm="3">
                    <MDBCardText>Contact Number</MDBCardText>
                  </MDBCol>
                  <MDBCol sm="9">
                    <MDBCardText className="text-muted">
                      {user && user.contactNumber ? user.contactNumber : "N/A"}
                    </MDBCardText>
                  </MDBCol>
                </MDBRow>
                <hr />
                <MDBRow>
                  <MDBCol sm="3">
                    <MDBCardText>Gender</MDBCardText>
                  </MDBCol>
                  <MDBCol sm="9">
                    <MDBCardText className="text-muted">
                      {user && user.gender ? user.gender : "N/A"}
                    </MDBCardText>
                  </MDBCol>
                </MDBRow>
                <hr />
                <MDBRow>
                  <MDBCol sm="3">
                    <MDBCardText>Date of Birth</MDBCardText>
                  </MDBCol>
                  <MDBCol sm="9">
                    <MDBCardText className="text-muted">
                      {user && user.dob ? user.dob : "N/A"}
                    </MDBCardText>
                  </MDBCol>
                </MDBRow>
                <hr />
                <MDBRow>
                  <MDBCol sm="3">
                    <MDBCardText>Skills</MDBCardText>
                  </MDBCol>
                  <MDBCol sm="9">
                    <MDBCardText className="text-muted">
                      {user && user.skills ? user.skills : "N/A"}
                    </MDBCardText>
                  </MDBCol>
                </MDBRow>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
        </MDBRow>

        <div style={{ display: "flex", justifyContent: "flex-end" }}>
          <Button
            variant="outlined"
            color="error"
            onClick={() => handleLogout()}
          >
            Logout
          </Button>
        </div>
      </MDBContainer>
    </section>
  );
}
