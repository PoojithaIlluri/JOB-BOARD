import React from "react";
import { Link } from "react-router-dom";

const PageNotFound = () => {
  return (
    <div
      style={{
        height: "70vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
      }}
    >
      <h1>Page Not Found</h1>
      <p>
        Go back to <Link to={"/"}>Home page</Link>
      </p>
    </div>
  );
};

export default PageNotFound;
