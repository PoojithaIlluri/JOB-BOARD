import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { loginApi } from "../api/loginApi";

const LoginPage = () => {
  const [user, setUser] = useState({ email: "", password: "" });

  const navigate = useNavigate();
  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser({ ...user, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const response = await loginApi(user);
    if (response.message === "success") {
      localStorage.setItem("token", response.token);
      navigate("/");
    } else {
      alert(response.errorMsg);
    }
  };

  return (
    <div className="login template d-flex justify-content-center align-items-center vh-100">
      <div className="form_container p-5 rounded-4 bg-white border border-2 shadow p-3 mb-5 bg-body-tertiary ">
        <form onSubmit={handleSubmit}>
          <h3 className="text-center">Login</h3>
          <div className="mb-2">
            <label htmlFor="email">Email Address</label>
            <input
              type="email"
              placeholder="Email Address"
              className="form-control"
              name="email"
              value={user.email}
              onChange={(e) => handleChange(e)}
            />
          </div>
          <div className="mb-2">
            <label htmlFor="Password">Password</label>
            <input
              type="password"
              placeholder="Password"
              className="form-control"
              name="password"
              value={user.password}
              onChange={(e) => handleChange(e)}
            />
          </div>
          <div className="mb-2">
            <input
              type="checkbox"
              className="custom-control custoem-checkbox"
              id="check"
            />
            <label htmlFor="check" className="custom-input-label ms-2">
              Remember me
            </label>
          </div>
          <div className="d-grid">
            <button className="btn btn-primary" type="submit">
              Login
            </button>
          </div>
          <p className="text-end mt-2 d-flex justify-content-between">
            <a href="?">Forgot Password?</a>
            <Link to="/register" className="ms-2">
              Register
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
};

export default LoginPage;
