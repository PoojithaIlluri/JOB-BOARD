import { Typography } from "@mui/material";
import React from "react";

const HomeProfile = ({user}) => {
  return (
    <div className="homeProfile">
      <img
        src={require("../assets/images/dummy.png")}
        alt="profile"
        style={{
          borderRadius: "50%",
          margin: "auto",
          display: "block",
          width: "150px",
          height: "150px",
          marginTop: "30px",
          objectFit: "cover"
        }}
      />
      <Typography variant="h5" sx={{ textAlign: "center", marginTop: "20px" }}>
        {user && user.fullname}
      </Typography>
      <Typography variant="body" sx={{ textAlign: "center", display: "block" }}>
        {user && user.description}
      </Typography>
      <Typography
        variant="h6"
        sx={{ textAlign: "center", display: "block", marginTop: "20px" }}
        >
        Skills
      </Typography>
      <Typography variant="body" sx={{ textAlign: "center", display: "block" }}>
        {user && user.skills}
      </Typography>
    </div>
  );
};

export default HomeProfile;
