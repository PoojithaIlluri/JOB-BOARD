import React from "react";

const About = () => {
  return (
    <div className="aboutus">
      <h1>About Us</h1>
      <p>
        Welcome to our job board website! We are dedicated to helping job
        seekers find their dream careers and employers connect with top talent.
      </p>
      <p>
        Our mission is to simplify the job search process and make it efficient
        for both job seekers and employers.
      </p>
      <h2>Our Team</h2>
      <p>
        We are a passionate team of developers, designers, and industry experts
        who believe in the power of technology to transform the hiring process.
      </p>
      <h2>Contact Us</h2>
      <p>
        If you have any questions, feedback, or suggestions, please don't
        hesitate to contact us:
      </p>
      <ul>
        <li>Email: kevin@jobboard.com</li>
        <li>Phone: 9390210561</li>
        <li>
          Address: Plot no.21&22,3rd Floor, Trendz Dwaraka,Gachibowli,HYD-500031
          www.imarticus.org
        </li>
      </ul>
    </div>
  );
};

export default About;
