import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { registerApi } from "../api/loginApi";

const RegisterPage = () => {
  const [user, setUser] = useState({
    fullname: "",
    email: "",
    password: "",
    cPassword: "",
  });

  const navigate = useNavigate();
  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser({ ...user, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (user.password !== user.cPassword) {
      alert("Password doesnot match!");
      return;
    }
    
    const response = await registerApi(user);
    if (response.message === "success") {
      localStorage.setItem("token", response.token);
      navigate("/");
    } else {
      alert(response.errorMsg);
    }
  };

  return (
    <div className="Register template d-flex justify-content-center align-items-center vh-100">
      <div className="form_container p-4 rounded-4 bg-white border border-2 shadow p-3 mb-5 bg-body-tertiary">
        <form onSubmit={handleSubmit}>
          <h3 className="text-center">Register</h3>
          <div className="mb-2">
            <label htmlFor="Username">Full Name</label>
            <input
              type="username"
              placeholder="username"
              className="form-control"
              name="fullname"
              value={user.fullname}
              onChange={(e) => handleChange(e)}
            />
          </div>
          <div className="mb-2">
            <label htmlFor="Email">Email</label>
            <input
              type="Email"
              placeholder="Email"
              className="form-control"
              name="email"
              value={user.email}
              onChange={(e) => handleChange(e)}
            />
          </div>
          <div className="mb-2">
            <label htmlFor="Password">Password</label>
            <input
              type="password"
              placeholder="Password"
              className="form-control"
              name="password"
              value={user.password}
              onChange={(e) => handleChange(e)}
            />
          </div>
          <div className="mb-2">
            <label htmlFor="confirm Password">confirm Password</label>
            <input
              type="password"
              placeholder=" Confirm Password"
              className="form-control"
              name="cPassword"
              value={user.cPassword}
              onChange={(e) => handleChange(e)}
            />
          </div>
          <div className="d-grid mt-2">
            <button className="btn btn-primary">Submit</button>
          </div>
          <p className="text-center mt-2">
            Already have an account?
            <Link to="/login" className="ms-2">
              Login
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
};

export default RegisterPage;
