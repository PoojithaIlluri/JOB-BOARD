import React, { useEffect, useState } from "react";
import {
  MDBCol,
  MDBContainer,
  MDBRow,
  MDBCard,
  MDBCardBody,
  MDBCardImage,
} from "mdb-react-ui-kit";
import { getAllApplicationsApi } from "../api/applications";
import { getUserApi } from "../api/loginApi";
import { getSingleJobApi } from "../api/jobs";
import { Link } from "react-router-dom";

const MyJobsPage = () => {
  const [applications, setApplications] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [user, setUser] = useState({});

  const fetchApplications = async () => {
    const response = await getAllApplicationsApi();
    setApplications(response.applications);
  };

  const fetchUser = async () => {
    const response = await getUserApi();
    if (response.message === "failed") {
      alert(response.errorMsg);
    } else {
      setUser(response.user);
    }
  };

  const fetchJobs = async () => {
    let newJobs = [];
    for (let i = 0; i < applications.length; i++) {
      const job = await getSingleJobApi(applications[i].jobId);
      newJobs = [...newJobs, job.job];
    }
    setJobs(newJobs);
  };

  useEffect(() => {
    fetchApplications();
    fetchUser();
  }, []);

  useEffect(() => {
    if (applications.length > 0) {
      fetchJobs();
    }
    // eslint-disable-next-line
  }, [applications]);

  return (
    <>
      <section style={{ backgroundColor: "#eee" }}>
        <MDBContainer className="py-5">
          <MDBRow>
            <MDBCol lg="4">
              <MDBCard className="mb-4">
                <MDBCardBody className="text-center">
                  <MDBCardImage
                    src={require("../assets/images/dummy.png")}
                    alt="avatar"
                    className="rounded-circle"
                    style={{
                      width: "200px",
                      height: "200px",
                      objectFit: "cover",
                    }}
                    fluid
                  />
                  <h4 className="my-1">{user && user.fullname}</h4>
                </MDBCardBody>
              </MDBCard>
            </MDBCol>
            <MDBCol lg="8">
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <h2>My Jobs</h2>
              </div>
              <div className="my-jobs">
                {jobs && jobs.length > 0 ? (
                  jobs.map((job) => (
                    <div className="my-job" key={job._id}>
                      <Link
                        to={`/single-job/${job._id}`}
                        className="single-job-link"
                      >
                        <h4>{job.name}</h4>
                      </Link>
                      <p>{job.company_name}</p>
                      <p>
                        {job.place} ({job.mode})
                      </p>
                    </div>
                  ))
                ) : (
                  <p>You have not applied to any job applications yet</p>
                )}
              </div>
            </MDBCol>
          </MDBRow>
        </MDBContainer>
      </section>
    </>
  );
};

export default MyJobsPage;
