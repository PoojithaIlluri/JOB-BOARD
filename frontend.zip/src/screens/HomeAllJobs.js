import React, { useState } from "react";
import HomeSearchField from "../components/HomeSearchField";
import JobCard from "../components/JobCard";

const HomeAllJobs = ({ jobs }) => {
  const [search, setSearch] = useState("");
  const [searchData,setSearchData]=useState(search);

  const handleSearch = () => {
    setSearchData(search);
  };

  return (
    <div className="homeAllJobs">
      <HomeSearchField
        search={search}
        setSearch={setSearch}
        handleSearch={handleSearch}
      />
      {jobs.length > 0 &&
        jobs
          .filter((job) => job.name.toLowerCase().includes(searchData.toLowerCase()))
          .map((job) => <JobCard key={job._id} job={job} />)}
    </div>
  );
};

export default HomeAllJobs;
