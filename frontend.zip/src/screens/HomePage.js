import React, { useEffect, useState } from "react";
import HomeProfile from "./HomeProfile";
import HomeAllJobs from "./HomeAllJobs";
import HomeRecent from "./HomeRecent";
import "../assets/styles/HomePage.css";
import { getAllJobsApi } from "../api/jobs";
import Spinner from "../components/Spinner";
import { getUserApi } from "../api/loginApi";
import AddDialog from "../components/AddJob";

const HomePage = () => {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchJobs = async () => {
    setLoading(true);
    const response = await getAllJobsApi();
    setLoading(false);
    if (response.message === "failed") {
      alert(response.errorMsg);
    } else {
      setJobs(response.jobs);
    }
  };

  const [user, setUser] = useState({});

  const fetchUser = async () => {
    const response = await getUserApi();
    if (response.message === "failed") {
      alert(response.errorMsg);
    } else {
      setUser(response.user);
    }
  };

  useEffect(() => {
    fetchJobs();
    fetchUser();
  }, []);

  return loading ? (
    <Spinner />
  ) : (
    <div className="homePage">
      <AddDialog user={user} />
      <HomeProfile user={user} />
      <HomeAllJobs jobs={jobs} />
      <HomeRecent jobs={jobs} />
    </div>
  );
};

export default HomePage;
