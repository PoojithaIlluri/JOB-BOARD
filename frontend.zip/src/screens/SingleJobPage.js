import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getSingleJobApi } from "../api/jobs";
import { Button } from "@mui/material";
import { applyJobApi } from "../api/applications";

const App = () => {
  const [job, setJob] = useState({});
  const { id } = useParams();

  const fetchJob = async () => {
    const response = await getSingleJobApi(id);
    if (response.message === "failed") {
      alert(response.errorMsg);
    } else {
      setJob(response.job);
    }
  };

  useEffect(() => {
    fetchJob();
    // eslint-disable-next-line
  }, []);

  const handleApply = async () => {
    const response = await applyJobApi(id);
    if (response && response.message === "success") {
      alert("Successfully you have applied to the job application");
    } else {
      alert(response.errorMsg);
    }
  };

  return (
    <div className="App">
      <Button
        variant="outlined"
        sx={{
          marginLeft: "auto",
          display: "block",
          marginRight: "20px",
          marginTop: "90px",
        }}
        onClick={() => handleApply()}
      >
        Apply Now
      </Button>
      <div className="job-page">
        <div className="job-info">
          <h2> Job Name</h2>
          <p>{job && job.name}</p>
          <h2>Company Name</h2>
          <p>
            {/* first letter in upper case */}
            {job &&
              job.company_name &&
              `${job.company_name.slice(0, 1).toUpperCase()}`}
            {/* all other letters in lower case */}
            {job &&
              job.company_name &&
              `${job.company_name.slice(1).toLowerCase()}`}
          </p>

          <h2>Required Skills</h2>
          <ul>
            {job &&
              job.skills &&
              job.skills.map((skill, index) => <li key={index}>{skill}</li>)}
          </ul>
        </div>
        <div className="job-description">
          <h2>Job Description</h2>
          <p>{job && job.description}</p>
          <h6>
            Required experience : <span>{job && job.experience} years</span>
          </h6>
          <h6>
            Job Location : <span>{job && job.place}</span>
          </h6>
          <h6>
            Salary : <span>{job && job.salary}</span>
          </h6>
          <h6>
            Job Mode : <span>{job && job.mode}</span>
          </h6>
          <h6>
            No of Openings : <span>{job && job.no_of_jobs}</span>
          </h6>
        </div>
      </div>
    </div>
  );
};

export default App;
