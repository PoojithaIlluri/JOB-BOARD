import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./App.css";
import LoginPage from "./screens/LoginPage";
import RegisterPage from "./screens/RegisterPage";
import HomePage from "./screens/HomePage";
import AboutPage from "./screens/AboutPage";
import SingleJobPage from "./screens/SingleJobPage";
import ContactPage from "./screens/ContactPage";
import Navigation from "./components/Navigation";
import MarginTop from "./components/MarginTop";
import PageNotFound from "./screens/PageNotFound";

import "@fontsource/roboto/300.css";
import "@fontsource/roboto/400.css";
import "@fontsource/roboto/500.css";
import "@fontsource/roboto/700.css";
import UserProfile from "./screens/UserProfile";
import Footer from "./components/Footer";
import MyJobsPage from "./screens/MyJobsPage";

function App() {
  return (
    <BrowserRouter>
      <Navigation />
      <MarginTop />
      <Routes>
        {/* authentication */}
        <Route exact path="/login" element={<LoginPage />} />
        <Route exact path="/register" element={<RegisterPage />} />

        {/* Pages */}
        <Route exact index path="/" element={<HomePage />} />
        <Route exact path="/single-job/:id" element={<SingleJobPage />} />
        <Route exact path="/about" element={<AboutPage />} />
        <Route exact path="/contact" element={<ContactPage />} />

        <Route exact path="/user-profile" element={<UserProfile />} />
        <Route exact path="/my-jobs" element={<MyJobsPage />} />
        <Route exact path="*" element={<PageNotFound />} />

      </Routes>
      <Footer/>
    </BrowserRouter>
  );
}

export default App;
