import * as React from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import EditInputField from "./EditInputField";
import { postJobApi } from "../api/jobs";

export default function AddDialog({ user }) {
  const [open, setOpen] = React.useState(false);

  const [details, setDetails] = React.useState({
    name: "",
    description: "",
    skills: [],
    experience: "",
    place: "",
    no_of_jobs: "",
    mode: "",
    salary: "",
    company_name: "",
  });

  const handleClickOpen = () => {
    setDetails({ ...details, [user]: user._id });
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setDetails({ ...details, [name]: value });
  };

  const addJob = async (data) => {
    const { skills, ...newObj } = data;
    const newSkills = details.skills.split(",");
    newObj.skills=newSkills;
    console.log(newObj);
    const response = await postJobApi(newObj);
    console.log(response);
  };

  return (
    <>
      <Button
        variant="outlined"
        className="add-post"
        onClick={() => handleClickOpen()}
      >
        Post Job
      </Button>
      <Dialog
        open={open}
        onClose={handleClose}
        PaperProps={{
          component: "form",
          onSubmit: async (e) => {
            e.preventDefault();
            const formData = new FormData(e.currentTarget);
            const formJson = Object.fromEntries(formData.entries());
            await addJob(formJson);
            window.location.reload();
            handleClose();
          },
        }}
      >
        <DialogTitle>Post Job</DialogTitle>
        <DialogContent>
          <EditInputField
            name="name"
            label="Job Title"
            value={details.name}
            handleChange={handleChange}
          />
          <EditInputField
            name="description"
            label="Job Description"
            value={details.description}
            handleChange={handleChange}
          />
          <EditInputField
            name="company_name"
            label="Company Name"
            value={details.company_name}
            handleChange={handleChange}
          />
          <EditInputField
            name="experience"
            label="Experience required"
            value={details.experience}
            handleChange={handleChange}
            type={"number"}
          />
          <EditInputField
            name="mode"
            label="Mode (Hybrid, Remote, On-site)"
            value={details.mode}
            handleChange={handleChange}
          />
          <EditInputField
            name="salary"
            label="Salary"
            value={details.salary}
            handleChange={handleChange}
            type={"number"}
          />
          <EditInputField
            name="skills"
            label="Skills required"
            value={details.skills}
            handleChange={handleChange}
          />
          <EditInputField
            name="no_of_jobs"
            label="No of openings"
            value={details.no_of_jobs}
            handleChange={handleChange}
            type={"number"}
          />
          <EditInputField
            name="place"
            label="Job location"
            value={details.place}
            handleChange={handleChange}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="error" variant="contained">
            Cancel
          </Button>
          <Button type="submit" color="success" variant="contained">
            Post
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
