import * as React from "react";
import Card from "@mui/material/Card";
import Typography from "@mui/material/Typography";
import { Link } from "react-router-dom";

export default function JobCard({ recent, job }) {
  const getDate = (date) => {
    const originalDateString = date;
    const originalDate = new Date(originalDateString);
    const day = originalDate.getUTCDate().toString().padStart(2, "0");
    const month = (originalDate.getUTCMonth() + 1).toString().padStart(2, "0"); // Month is zero-based, so we add 1
    const year = originalDate.getUTCFullYear();

    const formattedDate = `${day}/${month}/${year}`;
    return formattedDate;
  };
  return (
    <Card sx={{ width: "100%", margin: "20px 0px", padding: "10px" }}>
      <Typography gutterBottom variant="h6" component="div">
        <Link to={job && `/single-job/${job._id}`} className="single-job-link">
          {job && job.name}
        </Link>
      </Typography>
      <Typography variant="body2" color="text.secondary">
        {recent
          ? job && job.description.slice(0, 80)
          : job && job.description.slice(0, 250)}
        ...
      </Typography>
      <div style={{ display: "flex", justifyContent: "flex-end" }}>
        <Typography variant="body2">
          {!recent && job && getDate(job.date)}
        </Typography>
      </div>
    </Card>
  );
}
