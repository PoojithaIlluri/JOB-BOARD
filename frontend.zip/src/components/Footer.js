import React from "react";
import FacebookIcon from "@mui/icons-material/Facebook";
import XIcon from "@mui/icons-material/X";
import LinkedInIcon from "@mui/icons-material/LinkedIn";
import GitHubIcon from "@mui/icons-material/GitHub";
import EmailIcon from "@mui/icons-material/Email";
import LocalPhoneIcon from "@mui/icons-material/LocalPhone";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import { useLocation } from "react-router-dom";

const Footer = () => {
  const location = useLocation();
  if (location.pathname === "/") {
    return <></>;
  }
  return (
    <>
      <footer className="footer-distributed">
        <div className="footer-left">
          <h3>
            Jobs <span>Board</span>
          </h3>

          <p className="footer-links">
            <a href="/" className="link-1">
              Home
            </a>{" "}
            <a href="/about">About</a> <a href="/contact">Contact</a>{" "}
            <a href="/user-profile">Profile</a> <a href="/login">Login</a>
          </p>

          <p className="footer-company-name">
            Jobs Board <b>©</b> 2024
          </p>
        </div>

        <div className="footer-center">
          <div>
            <LocationOnIcon />{" "}
            <p>
              <span>444 S. Cedros Ave</span> Solana Beach, California
            </p>
          </div>

          <div>
            <LocalPhoneIcon /> <p>+1.555.555.5555</p>
          </div>

          <div>
            <EmailIcon />{" "}
            <p>
              <a href="mailto:support@company.com">support@company.com</a>
            </p>
          </div>
        </div>

        <div className="footer-right">
          <p className="footer-company-about">
            <span>About the company</span>
            Lorem ipsum dolor sit amet, consectateur adispicing elit. Fusce
            euismod convallis velit, eu auctor lacus vehicula sit amet.
          </p>

          <div className="footer-icons">
            <a href="/">
              <FacebookIcon />
            </a>
            <a href="/">
              <XIcon />
            </a>
            <a href="/">
              <LinkedInIcon />
            </a>
            <a href="/">
              <GitHubIcon />
            </a>
          </div>
        </div>
      </footer>
    </>
  );
};

export default Footer;
