import { TextField } from "@mui/material";
import React from "react";

const EditInputField = ({ name, label, value, handleChange, type }) => {
  return (
    <TextField
      required
      name={name}
      label={label}
      fullWidth
      variant="outlined"
      value={value}
      onChange={(e) => handleChange(e)}
      size="small"
      sx={{ m: 1 }}
      type={type ? type : "text"}
    />
  );
};

export default EditInputField;
