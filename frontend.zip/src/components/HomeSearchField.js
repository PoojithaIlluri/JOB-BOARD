import React from "react";
import {
  FormControl,
  IconButton,
  InputAdornment,
  OutlinedInput,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";

export default function HomeSearchField({search, setSearch,handleSearch}) {
  return (
    <FormControl size="small" sx={{width:'100%'}} variant="outlined">
      <OutlinedInput
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        fullWidth
        placeholder="Search Jobs or Company"
        endAdornment={
          <InputAdornment position="end">
            <IconButton
              onClick={()=>handleSearch()}
              edge="end"
              sx={{ p: "10px" }}
            >
              <SearchIcon />
            </IconButton>
          </InputAdornment>
        }
      />
    </FormControl>
  );
}
