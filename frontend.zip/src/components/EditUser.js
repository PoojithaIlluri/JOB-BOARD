import * as React from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import EditInputField from "./EditInputField";
import { updateUserApi } from "../api/loginApi";

export default function EditDialog({ user }) {
  const [open, setOpen] = React.useState(false);

  const [details, setDetails] = React.useState({
    fullname: "",
    email: "",
    role: "",
    contactNumber: "",
    gender: "",
    dob: "",
    description: "",
    skills: "",
  });

  const handleClickOpen = () => {
    setDetails({
      fullname: user && user.fullname ? user.fullname : "",
      email: user && user.email ? user.email : "",
      role: user && user.role ? user.role : "",
      contactNumber: user && user.contactNumber ? user.contactNumber : "",
      gender: user && user.gender ? user.gender : "",
      dob: user && user.dob ? user.dob : "",
      description: user && user.description ? user.description : "",
      skills: user && user.skills ? user.skills : "",
    });
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setDetails({ ...details, [name]: value });
  };
//   const location = useLocation();

  return (
    <React.Fragment>
      <Button
        variant="contained"
        sx={{ m: 1 }}
        onClick={() => handleClickOpen()}
      >
        Edit
      </Button>
      <Dialog
        open={open}
        onClose={handleClose}
        PaperProps={{
          component: "form",
          onSubmit: async (event) => {
            event.preventDefault();
            const formData = new FormData(event.currentTarget);
            const formJson = Object.fromEntries(formData.entries());
            const response = await updateUserApi(formJson);
            console.log(response);
            window.location.reload();
            handleClose();
          },
        }}
      >
        <DialogTitle>Update Profile</DialogTitle>
        <DialogContent>
          <EditInputField
            name="fullname"
            label="Full Name"
            value={details.fullname}
            handleChange={handleChange}
            required
          />
          <EditInputField
            name="email"
            label="Email Address"
            value={details.email}
            handleChange={handleChange}
            required
          />
          <EditInputField
            name="role"
            label="Role"
            value={details.role}
            handleChange={handleChange}
            required
          />
          <EditInputField
            name="contactNumber"
            label="Contact Number"
            value={details.contactNumber}
            handleChange={handleChange}
            type="number"
          />
          <EditInputField
            name="gender"
            label="Gender"
            value={details.gender}
            handleChange={handleChange}
          />
          <EditInputField
            name="dob"
            label="Date of Birth"
            value={details.dob}
            handleChange={handleChange}
          />
          <EditInputField
            name="description"
            label="Description"
            value={details.description}
            handleChange={handleChange}
          />
          <EditInputField
            name="skills"
            label="Skills"
            value={details.skills}
            handleChange={handleChange}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="error" variant="contained">
            Cancel
          </Button>
          <Button type="submit" color="success" variant="contained">
            Update
          </Button>
        </DialogActions>
      </Dialog>
    </React.Fragment>
  );
}
