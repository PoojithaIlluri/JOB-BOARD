const { default: mongoose } = require("mongoose");

const applicationModel = mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId },
  jobId: { type: mongoose.Schema.Types.ObjectId },
});

module.exports = mongoose.model("Application", applicationModel);
