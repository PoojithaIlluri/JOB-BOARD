const mongoose = require("mongoose");

const userSchema = mongoose.Schema(
  {
    fullname: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    role: { type: String, default: "user" }, // "admin" or "user"
    contactNumber: { type: String, default: "" },
    gender: { type: String, default: "" },
    dob: { type: String, default: "" },
    description: { type: String, default: "" },
    skills: [{ type: String, default: "" }],
  },
  {
    versionKey: false, // Disable the "__v" field
  }
);

module.exports = mongoose.model("User", userSchema);
