const mongoose = require("mongoose");
const { Schema } = mongoose;

const JobsSchema = new Schema({
  user: { type: mongoose.Schema.Types.ObjectId },
  name: { type: String, required: true },
  description: { type: String, required: true },
  skills: [{ type: String }],
  experience: { type: Number, required: true },
  place: { type: String, required: true },
  no_of_jobs: { type: Number, required: true },
  mode: { type: String, required: true }, // hybrid, on-site, remote
  salary: { type: Number, required: true },
  company_name: { type: String, required: true },
  date: { type: Date, default: Date.now },
});

module.exports = mongoose.model("jobs", JobsSchema);
