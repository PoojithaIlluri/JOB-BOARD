const mongoose = require("mongoose");

const connect = async () => {
  try {
    await mongoose.connect(process.env.DB_CONNECTION_STRING);
    console.log("successfully connected to db");
  } catch (error) {
    console.log("Error connecting db", error);
  }
};

module.exports = connect;
