const express = require("express");
const app = express();
const cors = require("cors");
require("dotenv").config();
const connect = require("./config/dbConnection");

const port = process.env.PORT;
connect(); // database connection

// middlewares
app.use(cors());
app.use(express.json());

// routes
app.use("/jobs", require("./routes/jobRoutes"));
app.use("/auth", require("./routes/userAuth"));
app.use("/applications", require("./routes/applicationsRoutes"));

// listen
app.listen(port, () => console.log("server is listening on port", port));
