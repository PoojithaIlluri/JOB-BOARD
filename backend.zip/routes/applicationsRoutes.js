const router = require("express").Router();
const validateUser = require("../middlewares/validateUser");
const Application = require("../models/applicationModel");

router.get("/", validateUser, async (req, res) => {
  const applications = await Application.find({user:req.user._id});
  res.status(200).json({ message: "success", applications });
});

router.get("/:id", validateUser, async (req, res) => {
  const id = req.params.id;
  const application = await Application.findOne({_id:id,user:req.user.id});

  if(!application){
    res.status(400).json({message:"failed",errorMsg:"You cannot access this application"});
    return;
  }
  
  if(req.user.id.toString()!==application.user.toString()){
    res.status(403).json({message:"failed",errorMsg:"You have no access this action"})
  }
  res.status(200).json({ message: "success", application });
});

router.post("/:id", validateUser, async (req, res) => {
  const id = req.params.id;
  const application = await Application.findOne({jobId:id,user:req.user._id});

  if(application){
    res.status(400).json({message:"failed",errorMsg:"You cannot apply for the same job more than once"});
    return;
  }

  const apply = await Application.create({
    user: req.user.id,
    jobId: id,
  });
  res.status(200).json({ message: "success", application: apply });
});

router.delete("/:id", validateUser, async (req, res) => {
  const id = req.params.id;
  const application = await Application.findOne({_id:id, user:req.user._id});

  if(!application){
    res.status(401).json({message:"failed",errorMsg:"You have not no access for this action"});
    return;
  }
  
  const apply = await Application.findByIdAndDelete(id);
  res.status(200).json({ message: "success", application: apply });
});

module.exports = router;
