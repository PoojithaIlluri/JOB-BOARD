const router = require("express").Router();
const validateUser = require("../middlewares/validateUser");
const Job = require("../models/jobsModel");

// @desc - Get all jobs details.
// @route - GET /jobs/
// @access - public
router.get("/", async (req, res) => {
  const jobs = await Job.find();
  res.status(200).json({ message: "succes", jobs });
});

// @desc - Get single job details
// @route - GET /jobs/:id
// @access - public
router.get("/:id", async (req, res) => {
  const id = req.params.id;
  const job = await Job.findById(id);
  res.status(200).json({ message: "success", job });
});

// @desc - Post a new job.
// @route - POST /jobs
// @access - authenticated
router.post("/", validateUser, async (req, res) => {
  const {
    name,
    description,
    skills,
    experience,
    place,
    no_of_jobs,
    mode,
    salary,
    company_name,
  } = req.body;
  if (
    !name ||
    !description ||
    !skills ||
    !experience ||
    !place ||
    !no_of_jobs ||
    !mode ||
    !salary ||
    !company_name
  ) {
    res.status(400).json({
      message: "failed",
      errorMsg: "Please enter all the required fields",
    });
    return;
  }
  const job = await Job.create({
    user: req.user._id,
    name,
    description,
    skills,
    experience,
    place,
    no_of_jobs,
    mode,
    salary,
    company_name,
  });
  res.status(201).json({ message: "success", job });
});

// @desc - Update job setails
// @route - PUT /jobs
// @access - the one who have posted job
router.put("/:id", validateUser, async (req, res) => {
  const id = req.params.id;
  const {
    name,
    desciption,
    skills,
    experience,
    place,
    no_of_jobs,
    mode,
    salary,
    company_name,
  } = req.body;

  const job = await Job.findById(id);
  if (!job) {
    res
      .status(400)
      .json({ message: "failed", errorMsg: "Troble finding the job details" });
    return;
  }
  if (job.user.toString() !== req.user._id.toString()) {
    res.status(403).json({
      message: "failed",
      errorMsg: "You have no access to updated this job",
    });
    return;
  }
  const updatedJob = await Job.findByIdAndUpdate(
    id,
    {
      name,
      desciption,
      skills,
      experience,
      place,
      no_of_jobs,
      mode,
      salary,
      company_name,
    },
    { new: true }
  );
  res.status(200).json({ message: "success", updatedJob });
});

router.delete("/:id", async (req, res) => {
  const id = req.params.id;
  const job = await Job.findById(id);
  if (!job) {
    res
      .status(400)
      .json({ message: "failed", errorMsg: "Troble finding the job details" });
    return;
  }
  const deletedJob = await Job.findByIdAndDelete(id);
  res.status(200).json({ message: "success", deletedJob });
});

module.exports = router;
