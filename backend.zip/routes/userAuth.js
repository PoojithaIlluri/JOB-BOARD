const router = require("express").Router();
const User = require("../models/userModel");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const validateUser = require("../middlewares/validateUser");

// @desc - Create a new user account.
// @route - POST /auth/register
// @access - public
router.post("/register", async (req, res) => {
  // check whether all required fields are entered
  const { fullname, email, password, role } = req.body;
  if (!fullname || !email || !password) {
    res.status(400).json({
      message: "failed",
      errorMsg: "Please enter required fields",
    });
  }
  // check user with this email already exists
  const checkUser = await User.findOne({ email });
  if (checkUser) {
    res.status(400).json({
      message: "failed",
      errorMsg: "User with this email already exists! Choose a unique email",
    });
  }
  const roleOfUser = role ? role : "user";
  // hash password
  const hashedPassword = await bcrypt.hash(password, 10);
  const user = await User.create({
    fullname,
    email,
    password: hashedPassword,
    role: roleOfUser,
  });
  if (!user) {
    res.status(500).json({
      message: "failed",
      errorMsg: "Internal server Error",
    });
  }
  // create json web token with secret key
  const token = jwt.sign(
    { user: { fullname, email, role: roleOfUser, id: user._id } },
    process.env.JWT_SECRET_KEY
  );
  res.status(201).json({
    message: "success",
    token,
  });
});

// @desc - Authenticate the user and issue an access token.
// @route - POST /auth/login
// @access - public
router.post("/login", async (req, res) => {
  // check whether all required fields are entered
  const { email, password } = req.body;
  if (!email || !password) {
    res.status(400).json({
      message: "failed",
      errorMsg: "Please enter required fields",
    });
  }
  // check whether the entered email is registered
  const user = await User.findOne({ email });
  if (!user) {
    res.status(401).json({
      message: "failed",
      errorMsg: "Invalid login credentials",
    });
    return;
  }
  // compare the enterd password and existing password
  const comparePassword = await bcrypt.compare(password, user.password);
  if (!comparePassword) {
    res.status(401).json({
      message: "failed",
      errorMsg: "Invalid login credentials",
    });
    return;
  }
  // create json web token with secret key
  const token = jwt.sign(
    {
      user: { fullname: user.fullname, email, role: user.role, id: user._id },
    },
    process.env.JWT_SECRET_KEY
  );
  res.status(200).json({
    message: "success",
    token,
  });
});

// @desc - Retrieve user profile information.
// @route - GET /auth
// @access - private - user access
router.get("/", validateUser, async (req, res) => {
  // check whether the user is logged in
  if (!req.user.id) {
    res.status(401).json({
      message: "failed",
      errorMsg: "You are not authorized",
    });
  }
  // get user details
  const user = await User.findById(req.user.id).select("-password");
  res.status(200).json({
    message: "success",
    user,
  });
});

// @desc - Update user profile information.
// @route - PUT /auth
// @access - public
router.put("/", validateUser, async (req, res) => {
  // check whether the user is logged in
  const user = req.user;
  if (!user.id) {
    res.status(401).json({
      message: "failed",
      errorMsg: "You are not authorized",
    });
  }

  // get all the deatils entered for updating the profile
  const { fullname, contactNumber, gender, dob, description, role, skills } =
    req.body;
  const getUser = await User.findById(user.id);
  const updateUser = await User.findByIdAndUpdate(
    user.id,
    { fullname, contactNumber, gender, dob, description, role, skills },
    { new: true }
  ).select("-password");

  // console.log(updateUser);

  // create json web token and return it as response
  const token = jwt.sign(
    {
      user: {
        fullname: updateUser.fullname,
        email: getUser.email,
        role: updateUser.role,
        id: updateUser.id,
      },
    },
    process.env.JWT_SECRET_KEY
  );
  res.json({
    message: "success",
    token,
  });
});

// @desc - Delete a user account.
// @route - DELETE /auth
// @access - private - user and admin access
router.delete("/", validateUser, async (req, res) => {
  // check whether the user is logged in
  const user = req.user;

  // delete user details
  const deletedUser = await User.findByIdAndDelete(user.id).select("-password");
  res.json({
    message: "success",
    deletedUser,
  });
});

module.exports = router;
